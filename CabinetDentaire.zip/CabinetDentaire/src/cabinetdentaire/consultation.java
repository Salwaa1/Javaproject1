/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cabinetdentaire;

import com.sbix.jnotify.NPosition;
import com.sbix.jnotify.NoticeType;
import com.sbix.jnotify.NoticeWindow;
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

/**
 *
 * @author LENOVO
 */
public class consultation extends javax.swing.JFrame {
       authentification a=new authentification();

    Connection con;
     ResultSet re;
 Statement st; 
 DefaultTableModel model=new  DefaultTableModel();
    public consultation() {
     
        initComponents();
          con = connexion.seconnecter();
            model=(DefaultTableModel) jTable2.getModel();

            remplirtableau();
            
              jButton1.setVisible(false);
        jButton7.setVisible(false);
        
         
String x=a.getSeletced();
        System.out.println(x);

if(x.equals("Administrateur"))
{jButton3.setVisible(true);
        
      jButton1.setVisible(true);
        
       jButton7.setVisible(true);

}
 
        
 
            
            
            
            
            
            
            
            remplircomb2();
                        remplircomb3();
            remplircomb1();

             AutoCompleteDecorator.decorate(this.jComboBox2);
             AutoCompleteDecorator.decorate(this.jComboBox1);
             AutoCompleteDecorator.decorate(this.jComboBox3);
             
      

    }
     
      public void remplirtableau(){
       
     
   
         
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_dentaire","root","");
            
            String req="select * from consultation";
            
            Statement pst=con.createStatement();
            ResultSet res=pst.executeQuery(req);
            
            
            model.setRowCount(0);
            while(res.next())
            {String idC=String.valueOf(res.getInt("idC"));
            String idp=res.getString("idp");
            String medicine=res.getString("medicines");
            String nom_dentalp=res.getString("nom_dentalp");
                      String costT=String.valueOf(res.getFloat("cost_t"));
          String costR=String.valueOf(res.getFloat("cost_r"));
          String desc=String.valueOf(res.getString("descr"));


            String tbData[]={idC,idp,medicine,nom_dentalp,costT,costR,desc};
            model.addRow(tbData);
            
            }
        } catch (Exception ex) {
            Logger.getLogger(consultation.class.getName()).log(Level.SEVERE, null, ex);
        }
         
         
         
      } 
        
     
        public void SearchA(String q)
  {             model=(DefaultTableModel) jTable2.getModel();

      TableRowSorter<DefaultTableModel> tr=new TableRowSorter<>(model);
  jTable2.setRowSorter(tr);
  tr.setRowFilter(RowFilter.regexFilter(q));
  
  }
        public void remplircomb1(){

    try {
      
        
        Class.forName("com.mysql.jdbc.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_dentaire","root","");
        st= con.createStatement();
        ResultSet res = st.executeQuery("select code from patients");
        while (res.next())
        {
            //Pour affecter une valeur de base de données à un Combobox
            jComboBox1.addItem(res.getString(1));
         }      
    } catch (Exception ex) {
        Logger.getLogger(appointment.class.getName()).log(Level.SEVERE, null, ex);
    }
    }public void remplircomb2(){

    try {
      
        
        Class.forName("com.mysql.jdbc.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_dentaire","root","");
        st= con.createStatement();
        ResultSet res = st.executeQuery("select nom_dentalp from dentalp");
        while (res.next())
        {
            //Pour affecter une valeur de base de données à un Combobox
            jComboBox2.addItem(res.getString(1));}
    } catch (Exception ex) {
        Logger.getLogger(appointment.class.getName()).log(Level.SEVERE, null, ex);
    }
    }
public void remplircomb3(){

    try {
      
        
        Class.forName("com.mysql.jdbc.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_dentaire","root","");
        st= con.createStatement();
        ResultSet res = st.executeQuery("select medicines from treatment");
        while (res.next())
        {
            //Pour affecter une valeur de base de données à un Combobox
            jComboBox3.addItem(res.getString(1));}
    } catch (Exception ex) {
        Logger.getLogger(appointment.class.getName()).log(Level.SEVERE, null, ex);
    }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jButton10 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jTextField9 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jTextField14 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jTextField4 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(49, 51, 75));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.setMaximumSize(new java.awt.Dimension(290, 850));
        jPanel2.setLayout(null);

        jButton3.setBackground(new java.awt.Color(49, 51, 75));
        jButton3.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-hand-with-a-pill-30.png"))); // NOI18N
        jButton3.setText("    Prescriptions");
        jButton3.setBorder(null);
        jButton3.setBorderPainted(false);
        jButton3.setContentAreaFilled(false);
        jButton3.setOpaque(true);
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton3MouseExited(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3);
        jButton3.setBounds(-40, 270, 340, 60);

        jButton2.setBackground(new java.awt.Color(49, 51, 75));
        jButton2.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-treatment-30 (1).png"))); // NOI18N
        jButton2.setText("   Traitements   ");
        jButton2.setBorder(null);
        jButton2.setBorderPainted(false);
        jButton2.setContentAreaFilled(false);
        jButton2.setOpaque(true);
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton2MouseExited(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2);
        jButton2.setBounds(-30, 390, 310, 70);

        jButton4.setBackground(new java.awt.Color(49, 51, 75));
        jButton4.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-home-30.png"))); // NOI18N
        jButton4.setText("   Home");
        jButton4.setBorder(null);
        jButton4.setBorderPainted(false);
        jButton4.setContentAreaFilled(false);
        jButton4.setOpaque(true);
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton4MouseExited(evt);
            }
        });
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton4);
        jButton4.setBounds(-100, 200, 380, 70);

        jButton6.setBackground(new java.awt.Color(49, 51, 75));
        jButton6.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-logout-rounded-down-30.png"))); // NOI18N
        jButton6.setText(" Se déconnecter");
        jButton6.setBorder(null);
        jButton6.setBorderPainted(false);
        jButton6.setContentAreaFilled(false);
        jButton6.setOpaque(true);
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton6MouseExited(evt);
            }
        });
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton6);
        jButton6.setBounds(0, 780, 280, 70);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-tooth-100 (1).png"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(0, 0, 92, 100);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 3, 28)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Cabinet dentaire");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(80, 60, 210, 40);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Consultation");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(130, 100, 140, 28);

        jButton5.setBackground(new java.awt.Color(49, 51, 75));
        jButton5.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-dental-floss-30.png"))); // NOI18N
        jButton5.setText("  Actes dentaires");
        jButton5.setBorder(null);
        jButton5.setBorderPainted(false);
        jButton5.setContentAreaFilled(false);
        jButton5.setOpaque(true);
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton5MouseExited(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5);
        jButton5.setBounds(-20, 330, 300, 60);

        jButton1.setBackground(new java.awt.Color(49, 51, 75));
        jButton1.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-cast-30.png"))); // NOI18N
        jButton1.setText("   patients      ");
        jButton1.setBorder(null);
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setOpaque(true);
        jButton1.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                jButton1MouseWheelMoved(evt);
            }
        });
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton1MouseExited(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);
        jButton1.setBounds(-60, 460, 360, 50);

        jButton7.setBackground(new java.awt.Color(49, 51, 75));
        jButton7.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-appointment-30.png"))); // NOI18N
        jButton7.setText("   Rendez-Vous");
        jButton7.setBorder(null);
        jButton7.setBorderPainted(false);
        jButton7.setContentAreaFilled(false);
        jButton7.setOpaque(true);
        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton7MouseExited(evt);
            }
        });
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton7);
        jButton7.setBounds(-50, 510, 360, 50);

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 280, 850));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setMaximumSize(new java.awt.Dimension(1090, 850));
        jPanel3.setLayout(null);

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Times New Roman", 3, 48)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(74, 31, 61));
        jLabel5.setText("Consultation");
        jPanel3.add(jLabel5);
        jLabel5.setBounds(410, 10, 320, 56);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel6.setText("Description");
        jPanel3.add(jLabel6);
        jLabel6.setBounds(370, 160, 200, 40);

        jLabel7.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel7.setText("Code patient");
        jPanel3.add(jLabel7);
        jLabel7.setBounds(20, 100, 170, 40);

        jLabel12.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel12.setText("Recu");
        jPanel3.add(jLabel12);
        jLabel12.setBounds(590, 220, 180, 40);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel8.setText("Montant à payer");
        jPanel3.add(jLabel8);
        jLabel8.setBounds(210, 220, 180, 40);

        jLabel9.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel9.setText("Médicament");
        jPanel3.add(jLabel9);
        jLabel9.setBounds(20, 160, 150, 40);

        jTextField3.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        jPanel3.add(jTextField3);
        jTextField3.setBounds(690, 220, 190, 40);

        jTextField2.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jPanel3.add(jTextField2);
        jTextField2.setBounds(390, 220, 190, 40);

        jButton10.setBackground(new java.awt.Color(0, 92, 131));
        jButton10.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setText("Ajouter");
        jButton10.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton10.setBorderPainted(false);
        jButton10.setContentAreaFilled(false);
        jButton10.setOpaque(true);
        jButton10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton10MouseExited(evt);
            }
        });
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton10);
        jButton10.setBounds(290, 310, 150, 40);

        jButton9.setBackground(new java.awt.Color(0, 92, 131));
        jButton9.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setText("Modifier");
        jButton9.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton9.setBorderPainted(false);
        jButton9.setContentAreaFilled(false);
        jButton9.setOpaque(true);
        jButton9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton9MouseExited(evt);
            }
        });
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton9);
        jButton9.setBounds(610, 310, 150, 40);

        jButton8.setBackground(new java.awt.Color(0, 92, 131));
        jButton8.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("Supprimer");
        jButton8.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jButton8.setBorderPainted(false);
        jButton8.setContentAreaFilled(false);
        jButton8.setOpaque(true);
        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton8MouseExited(evt);
            }
        });
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton8);
        jButton8.setBounds(450, 310, 150, 40);

        jPanel4.setBackground(new java.awt.Color(49, 51, 75));
        jPanel4.setForeground(new java.awt.Color(74, 31, 61));
        jPanel4.setLayout(null);

        jTextField9.setEditable(false);
        jTextField9.setBackground(new java.awt.Color(49, 51, 75));
        jTextField9.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jTextField9.setForeground(new java.awt.Color(255, 255, 255));
        jTextField9.setText("Code  Patient");
        jTextField9.setBorder(null);
        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField9);
        jTextField9.setBounds(150, 0, 150, 40);

        jTextField11.setEditable(false);
        jTextField11.setBackground(new java.awt.Color(49, 51, 75));
        jTextField11.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jTextField11.setForeground(new java.awt.Color(255, 255, 255));
        jTextField11.setText("   Description");
        jTextField11.setBorder(null);
        jTextField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField11ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField11);
        jTextField11.setBounds(880, 0, 150, 40);

        jTextField12.setEditable(false);
        jTextField12.setBackground(new java.awt.Color(49, 51, 75));
        jTextField12.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jTextField12.setForeground(new java.awt.Color(255, 255, 255));
        jTextField12.setText("Code");
        jTextField12.setBorder(null);
        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField12);
        jTextField12.setBounds(0, 0, 150, 40);

        jTextField15.setEditable(false);
        jTextField15.setBackground(new java.awt.Color(49, 51, 75));
        jTextField15.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jTextField15.setForeground(new java.awt.Color(255, 255, 255));
        jTextField15.setText("    Prix à payer");
        jTextField15.setBorder(null);
        jTextField15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField15ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField15);
        jTextField15.setBounds(600, 0, 150, 40);

        jTextField14.setEditable(false);
        jTextField14.setBackground(new java.awt.Color(49, 51, 75));
        jTextField14.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jTextField14.setForeground(new java.awt.Color(255, 255, 255));
        jTextField14.setText("    Médicaments");
        jTextField14.setBorder(null);
        jTextField14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField14ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField14);
        jTextField14.setBounds(300, 0, 150, 40);

        jTextField13.setEditable(false);
        jTextField13.setBackground(new java.awt.Color(49, 51, 75));
        jTextField13.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jTextField13.setForeground(new java.awt.Color(255, 255, 255));
        jTextField13.setText("  Actes dentaires");
        jTextField13.setBorder(null);
        jTextField13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField13ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField13);
        jTextField13.setBounds(450, 0, 150, 40);

        jTextField16.setEditable(false);
        jTextField16.setBackground(new java.awt.Color(49, 51, 75));
        jTextField16.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jTextField16.setForeground(new java.awt.Color(255, 255, 255));
        jTextField16.setText("    Recu    ");
        jTextField16.setBorder(null);
        jTextField16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField16ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField16);
        jTextField16.setBounds(750, 0, 150, 40);

        jPanel3.add(jPanel4);
        jPanel4.setBounds(30, 430, 1040, 40);

        jScrollPane2.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        jTable2=new javax.swing.JTable(){

            public boolean isCellEditable(int RowIndex,int colIndex)
            {return false;
            }
        };
        jTable2.setFont(new java.awt.Font("Times New Roman", 3, 20)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7"
            }
        ));
        jTable2.setGridColor(new java.awt.Color(255, 255, 255));
        jTable2.setIntercellSpacing(new java.awt.Dimension(0, 0));
        jTable2.setMaximumSize(new java.awt.Dimension(375, 442));
        jTable2.setRowHeight(34);
        jTable2.setSelectionBackground(new java.awt.Color(0, 92, 131));
        jTable2.setShowVerticalLines(false);
        jTable2.getTableHeader().setReorderingAllowed(false);
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable2MouseReleased(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jPanel3.add(jScrollPane2);
        jScrollPane2.setBounds(30, 440, 1040, 400);

        jTextField4.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jTextField4.setBorder(null);
        jTextField4.setOpaque(false);
        jTextField4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField4KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField4KeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField4KeyTyped(evt);
            }
        });
        jPanel3.add(jTextField4);
        jTextField4.setBounds(380, 380, 270, 30);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/search.jpg"))); // NOI18N
        jPanel3.add(jLabel4);
        jLabel4.setBounds(330, 360, 440, 70);

        jLabel11.setBackground(new java.awt.Color(255, 0, 0));
        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel11.setText("X");
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel11MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel11MouseExited(evt);
            }
        });
        jPanel3.add(jLabel11);
        jLabel11.setBounds(1100, 0, 20, 30);

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/ref2.png"))); // NOI18N
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel14MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel14MouseExited(evt);
            }
        });
        jPanel3.add(jLabel14);
        jLabel14.setBounds(1040, 400, 30, 30);

        jLabel10.setBackground(new java.awt.Color(0, 102, 102));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setText("X");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel10MouseExited(evt);
            }
        });
        jPanel3.add(jLabel10);
        jLabel10.setBounds(1070, 0, 20, 30);

        jComboBox3.setEditable(true);
        jComboBox3.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jPanel3.add(jComboBox3);
        jComboBox3.setBounds(170, 160, 190, 40);

        jComboBox1.setEditable(true);
        jComboBox1.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jPanel3.add(jComboBox1);
        jComboBox1.setBounds(170, 100, 190, 40);

        jComboBox2.setEditable(true);
        jComboBox2.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jComboBox2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox2ItemStateChanged(evt);
            }
        });
        jPanel3.add(jComboBox2);
        jComboBox2.setBounds(550, 100, 490, 40);

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jPanel3.add(jScrollPane1);
        jScrollPane1.setBounds(550, 150, 490, 50);

        jLabel13.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel13.setText("Actes dentaires");
        jPanel3.add(jLabel13);
        jLabel13.setBounds(370, 100, 200, 40);

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 2, 1100, 850));

        setSize(new java.awt.Dimension(1376, 849));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton10MouseEntered
jButton10.setToolTipText("Add Consultation");

        Color A = jButton10.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton10.setBackground(jButton10.getForeground());
        jButton10.setForeground(A);
    }//GEN-LAST:event_jButton10MouseEntered

    private void jButton10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton10MouseExited
      

        Color A = jButton10.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton10.setBackground(jButton10.getForeground());
        jButton10.setForeground(A);
    }//GEN-LAST:event_jButton10MouseExited

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed

           
 if( jComboBox2.getSelectedItem().toString().equals("") || jComboBox1.getSelectedItem().toString().equals("")||  jComboBox3.getSelectedItem().toString().equals("")
         ||  jTextField2.getText().equals("")    ||  jTextField3.getText().equals("") ||jTextArea1.getText().equals("")  )
        
 {new NoticeWindow(NoticeType.WARNING_NOTIFICATION,"please complete all fields",NoticeWindow.SHORT_DELAY,NPosition.CENTER);}
 else{
     String re1="^([+-]?\\d*\\.?\\d*)$";
 Pattern patt=Pattern.compile(re1);
      Matcher match=patt.matcher(jTextField2.getText());
      Pattern patt2=Pattern.compile(re1);
      Matcher match2=patt.matcher(jTextField3.getText());
      if(!match.matches() ||!match2.matches())
{          new NoticeWindow(NoticeType.WARNING_NOTIFICATION,"Invalid entry!",NoticeWindow.SHORT_DELAY,NPosition.CENTER);
   
}   
      
      
else{
      
             try {
           
                  /*  String req="insert into rendezvous(id,nom,dateR,heure,objet) values('','"+ jComboBox1.getSelectedItem().toString()
            +"','"+d1+"','"+jComboBox2.getSelectedItem().toString()+"','"
            +jComboBox4.getSelectedItem().toString()+"')";  
                    */
                    
                      Class.forName("com.mysql.jdbc.Driver");
                 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_dentaire","root","");
                  
                 String req="insert into consultation(idp,medicines,nom_dentalp,cost_t,cost_r,descr) values(?,?,?,?,?,?)";
               PreparedStatement  st=con.prepareStatement(req);
              

                 st.setString(1,jComboBox1.getSelectedItem().toString());
                 st.setString(2,jComboBox3.getSelectedItem().toString());
                 st.setString(3,jComboBox2.getSelectedItem().toString());
                 st.setString(4,jTextField2.getText().toString());
                 st.setString(5,jTextField3.getText().toString());
                                  st.setString(6,jTextArea1.getText().toString());



                 st.executeUpdate();
                 
                 new NoticeWindow(NoticeType.SUCCESS_NOTIFICATION,"Operation done!",NoticeWindow.NORMAL_DELAY,NPosition.CENTER);

                
                 
                  
  jComboBox2.setSelectedItem("");
              jComboBox1.setSelectedItem("");

        jComboBox3.setSelectedItem("");
        jTextField3.setText("");
        jTextField2.setText("");

              jTextArea1.setText("");
                
                 new NoticeWindow(NoticeType.SUCCESS_NOTIFICATION,"Operation done!",NoticeWindow.NORMAL_DELAY,NPosition.CENTER);

                 remplirtableau();
           
                    
             } catch (Exception ex) {
             new NoticeWindow(NoticeType.ERROR_NOTIFICATION,ex.toString(),NoticeWindow.NORMAL_DELAY,NPosition.CENTER);

             }
      
      
      
    /*if(!match.matches() || !match2.matches() || !match3.matches()||!match4.matches() || !isNumeric || !Isdate)
     {trayicon();
     }
     else{
     
                     JOptionPane.showMessageDialog(this," bien");

     }
     */}}       
        
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseEntered
jButton9.setToolTipText("Edit Consultation");

        Color A = jButton9.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton9.setBackground(jButton9.getForeground());
        jButton9.setForeground(A);
    }//GEN-LAST:event_jButton9MouseEntered

    private void jButton9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseExited
        Color A = jButton9.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton9.setBackground(jButton9.getForeground());
        jButton9.setForeground(A);
    }//GEN-LAST:event_jButton9MouseExited

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
 

       if( jComboBox2.getSelectedItem().toString().equals("")|| jComboBox1.getSelectedItem().toString().equals("")||  jComboBox3.getSelectedItem().toString().equals("")
         ||  jTextField2.getText().equals("")    ||  jTextField3.getText().equals("")   )
        
 {new NoticeWindow(NoticeType.WARNING_NOTIFICATION,"please complete all fields",NoticeWindow.SHORT_DELAY,NPosition.CENTER);}
 else{
     String re1="^([+-]?\\d*\\.?\\d*)$";
 Pattern patt=Pattern.compile(re1);
      Matcher match=patt.matcher(jTextField2.getText());
      Pattern patt2=Pattern.compile(re1);
      Matcher match2=patt.matcher(jTextField3.getText());
      if(!match.matches() ||!match2.matches())
{          new NoticeWindow(NoticeType.WARNING_NOTIFICATION,"Invalid entry!",NoticeWindow.SHORT_DELAY,NPosition.CENTER);
   
}   
      
      
else{
      
             try {

                     Class.forName("com.mysql.jdbc.Driver");
                 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_dentaire","root","");
                  int code=jTable2.getSelectedRow();
                    String selectionner=model.getValueAt(code,0).toString();
                 String req="update consultation set idp=?,medicines=?,nom_dentalp =?,cost_t =?,cost_r=?,descr=? where idC="+selectionner;
               PreparedStatement  st=con.prepareStatement(req);
              

                 st.setString(1,jComboBox1.getSelectedItem().toString());
                 st.setString(2,jComboBox3.getSelectedItem().toString());
                 st.setString(3,jComboBox2.getSelectedItem().toString());
                 st.setString(4,jTextField2.getText().toString());
                 st.setString(5,jTextField3.getText().toString());
                                  st.setString(6,jTextArea1.getText().toString());


                

                 st.executeUpdate();
                        new NoticeWindow(NoticeType.SUCCESS_NOTIFICATION,"Operation done!",NoticeWindow.NORMAL_DELAY,NPosition.CENTER);

                        remplirtableau();
jComboBox2.setSelectedItem("");
              jComboBox1.setSelectedItem("");

        jComboBox3.setSelectedItem("");
        jTextField3.setText("");
        jTextField2.setText("");

                                jTextArea1.setText("");
 

                } catch (Exception ex) {
                    new NoticeWindow(NoticeType.ERROR_NOTIFICATION,ex.toString(),NoticeWindow.NORMAL_DELAY,NPosition.CENTER);

                }

                /*if(!match.matches() || !match2.matches() || !match3.matches()||!match4.matches() || !isNumeric || !Isdate)
                {trayicon();
                }
                else{

                    JOptionPane.showMessageDialog(this," bien");

                }
                */}}      
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseEntered
jButton8.setToolTipText("Delete Consultation");

        Color A = jButton8.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton8.setBackground(jButton8.getForeground());
        jButton8.setForeground(A);
    }//GEN-LAST:event_jButton8MouseEntered

    private void jButton8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseExited
        Color A = jButton8.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton8.setBackground(jButton8.getForeground());
        jButton8.setForeground(A);
    }//GEN-LAST:event_jButton8MouseExited

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed

           if (JOptionPane.showConfirmDialog(null, "Are you sure to delete?")==JOptionPane.YES_OPTION){

            try {
               int code=jTable2.getSelectedRow();
                String selectionner=(String)jTable2.getValueAt(code,0);

                 Class.forName("com.mysql.jdbc.Driver");
                 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_dentaire","root","");
                  
                 String req="delete from consultation where idC=?";
               PreparedStatement  st=con.prepareStatement(req);
                 st.setString(1,selectionner);
                 

                 st.executeUpdate();
                
                
                
                
                
               
                    new NoticeWindow(NoticeType.SUCCESS_NOTIFICATION,"Deleted !",NoticeWindow.SHORT_DELAY,NPosition.CENTER);
                    remplirtableau();

            


            } catch (Exception ex) {
                new NoticeWindow(NoticeType.ERROR_NOTIFICATION,ex.toString(),NoticeWindow.NORMAL_DELAY,NPosition.CENTER);
            }}
        
        
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField12ActionPerformed

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField9ActionPerformed

    private void jTextField13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField13ActionPerformed

    private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField11ActionPerformed

    private void jTextField14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField14ActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable2MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseReleased
         int selctedC=jTable2.getSelectedRow();
        jComboBox1.setSelectedItem(model.getValueAt(selctedC, 1).toString());
        jComboBox3.setSelectedItem(model.getValueAt(selctedC, 2).toString());
        jComboBox2.setSelectedItem(model.getValueAt(selctedC, 3).toString());
        jTextField2.setText(model.getValueAt(selctedC, 4).toString());
        jTextField3.setText(model.getValueAt(selctedC, 5).toString());
        jTextArea1.setText(model.getValueAt(selctedC, 6).toString());

      
    }//GEN-LAST:event_jTable2MouseReleased

    private void jTextField4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField4KeyPressed

        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4KeyPressed

    private void jTextField4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField4KeyReleased
          String x=jTextField4.getText();
        SearchA(x);
    }//GEN-LAST:event_jTextField4KeyReleased

    private void jTextField4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField4KeyTyped

    }//GEN-LAST:event_jTextField4KeyTyped

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel11MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseEntered
        Color c = jLabel5.getBackground(); // When the mouse moves over a label, the background color changed.
        jLabel5.setBackground(jLabel5.getForeground());
        jLabel5.setForeground(c);
    }//GEN-LAST:event_jLabel11MouseEntered

    private void jLabel11MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseExited
        Color c = jLabel5.getBackground(); // When the mouse moves over a label, the background color changed.
        jLabel5.setBackground(jLabel5.getForeground());
        jLabel5.setForeground(c);
    }//GEN-LAST:event_jLabel11MouseExited

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
 remplirtableau();
        jTextField2.setText("");
        //jTextArea2.setText("");
        jTextField3.setText("");
        jComboBox1.setSelectedItem("");
       jComboBox2.setSelectedItem("");     
              jComboBox3.setSelectedItem("");    
              jTextArea1.setText("");

    }//GEN-LAST:event_jLabel14MouseClicked

    private void jLabel14MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseEntered

        jLabel14.setIcon(new ImageIcon(getClass().getResource("IMG_P/icons8-refresh-30.png")));
    }//GEN-LAST:event_jLabel14MouseEntered

    private void jLabel14MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseExited

        jLabel14.setIcon(new ImageIcon(getClass().getResource("IMG_P/ref2.png")));
    }//GEN-LAST:event_jLabel14MouseExited

    private void jLabel10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseExited
        Color c = jLabel10.getBackground(); // When the mouse moves over a label, the background color changed.
        jLabel10.setBackground(jLabel10.getForeground());
        jLabel10.setForeground(c);
    }//GEN-LAST:event_jLabel10MouseExited

    private void jLabel10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseEntered
        Color c = jLabel10.getBackground(); // When the mouse moves over a label, the background color changed.
        jLabel10.setBackground(jLabel10.getForeground());
        jLabel10.setForeground(c);
    }//GEN-LAST:event_jLabel10MouseEntered

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel10MouseClicked

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        this.dispose();
        new authentification().setVisible(true);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseExited
        Color c = jButton6.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton6.setBackground(jButton6.getForeground());
        jButton6.setForeground(c);
    }//GEN-LAST:event_jButton6MouseExited

    private void jButton6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseEntered
        Color c = jButton6.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton6.setBackground(jButton6.getForeground());
        jButton6.setForeground(c);
    }//GEN-LAST:event_jButton6MouseEntered

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
     
        setVisible(false);

        
        String x=a.getSeletced();
        System.out.println(x);
if(x.equals("Médecin")){
new acceuil2().setVisible(true);
}
else{
if(x.equals("Secrétaire")){
new Acceuil().setVisible(true);


}
else{if(x.equals("Administrateur")){
new acceuil_admin().setVisible(true);
    }

}
     
} 





// setVisible(false);
        //new acceuil2().setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseExited
        Color c = jButton4.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton4.setBackground(jButton4.getForeground());
        jButton4.setForeground(c);
    }//GEN-LAST:event_jButton4MouseExited

    private void jButton4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseEntered
        Color c = jButton4.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton4.setBackground(jButton4.getForeground());
        jButton4.setForeground(c);
    }//GEN-LAST:event_jButton4MouseEntered

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField15ActionPerformed

    private void jComboBox2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox2ItemStateChanged

       
                  
        
        
    }//GEN-LAST:event_jComboBox2ItemStateChanged

    private void jTextField16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField16ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        setVisible(false);
        new Treatment().setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseExited
        Color A = jButton2.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton2.setBackground(jButton2.getForeground());
        jButton2.setForeground(A);
    }//GEN-LAST:event_jButton2MouseExited

    private void jButton2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseEntered
        Color A = jButton2.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton2.setBackground(jButton2.getForeground());
        jButton2.setForeground(A);
    }//GEN-LAST:event_jButton2MouseEntered

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        setVisible(false);
        new dental_procedure().setVisible(true);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseExited
        Color c = jButton5.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton5.setBackground(jButton5.getForeground());
        jButton5.setForeground(c);
    }//GEN-LAST:event_jButton5MouseExited

    private void jButton5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseEntered
        Color c = jButton5.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton5.setBackground(jButton5.getForeground());
        jButton5.setForeground(c);
    }//GEN-LAST:event_jButton5MouseEntered

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        setVisible(false);
        new Prescriptions().setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseExited
        Color c = jButton3.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton3.setBackground(jButton3.getForeground());
        jButton3.setForeground(c);
    }//GEN-LAST:event_jButton3MouseExited

    private void jButton3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseEntered
        Color c = jButton3.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton3.setBackground(jButton3.getForeground());
        jButton3.setForeground(c);
    }//GEN-LAST:event_jButton3MouseEntered

    private void jButton1MouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_jButton1MouseWheelMoved

    }//GEN-LAST:event_jButton1MouseWheelMoved

    private void jButton1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseEntered
        Color c = jButton1.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton1.setBackground(jButton1.getForeground());
        jButton1.setForeground(c);
    }//GEN-LAST:event_jButton1MouseEntered

    private void jButton1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseExited
        //if(!this.contains(evt.getPoint())) {
            //    jButton1.setBackground(Color.RED);
            //    }
        //else { jButton1.setBackground(Color.gray);
            //}

        Color c = jButton1.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton1.setBackground(jButton1.getForeground());
        jButton1.setForeground(c);
    }//GEN-LAST:event_jButton1MouseExited

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        setVisible(false);
        new Patients1().setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MouseEntered
       Color c = jButton7.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton7.setBackground(jButton7.getForeground());
        jButton7.setForeground(c);
    }//GEN-LAST:event_jButton7MouseEntered

    private void jButton7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MouseExited
        Color c = jButton7.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton7.setBackground(jButton7.getForeground());
        jButton7.setForeground(c);
    }//GEN-LAST:event_jButton7MouseExited

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        setVisible(false);
        new appointment().setVisible(true);
    }//GEN-LAST:event_jButton7ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(consultation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(consultation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(consultation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(consultation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new consultation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    public javax.swing.JTextField jTextField2;
    public javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
