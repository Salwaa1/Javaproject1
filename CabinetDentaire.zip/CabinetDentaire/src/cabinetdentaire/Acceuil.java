//


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cabinetdentaire;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

/**
 *
 * @author LENOVO
 */
public class Acceuil extends javax.swing.JFrame {
  Connection con;
     ResultSet res2,res3;
          ResultSet re,res4,res5;

 Statement st;
 Statement st2,st3,st4,st5;  
    public Acceuil() {
     initComponents();
       sec.setVisible(false);
          getnumbers();
        
           /*try {
          
         
          Class.forName("com.mysql.jdbc.Driver");
          con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_dentaire","root","");
          
          String req="select username,type from login where type='Secrétaire'";         
          
          Statement pst=con.createStatement();
          ResultSet res=pst.executeQuery(req);
          String code = null;
         
          
    
               

          while(res.next())
          { code=res.getString("username");
        
          
          }
         welcome.setText("Welcome "+code);
          
      } catch (Exception ex) { 
          Logger.getLogger(Acceuil.class.getName()).log(Level.SEVERE, null, ex);
      }*/
    }

    public void getnumbers()
    { try {
        Class.forName("com.mysql.jdbc.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_dentaire","root","");
                st=con.createStatement();
                st2=con.createStatement();
                st4=con.createStatement();
                st5=con.createStatement();

 re=st.executeQuery("select count(*) from patients");
   res4=st4.executeQuery("select count(*) from ren");
   Date date = new Date();
      SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

       String str = formatter.format(date); 
      res5=st5.executeQuery("select count(*) from ren where dateR='"+str+"'");

    //res5=st5.executeQuery("select count(*) from patients where "); 
    //res6=st6.executeQuery("select count(*) from treatment");
 while(re.next())
 {noP.setText("  "+re.getInt(1));
 }
 
  /* while(res3.next())
 {noPr.setText("  "+res3.getInt(1));
 }*/
    while(res4.next())
 {noAP.setText("  "+res4.getInt(1));
 }
  while(res5.next())
 {noAP1.setText("  "+res5.getInt(1));
 }      
        
      } catch (Exception ex) {
          Logger.getLogger(Acceuil.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel14 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        noP = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        noAP = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        noAP1 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(49, 51, 75));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-tooth-100 (1).png"))); // NOI18N
        jPanel2.add(jLabel2);
        jLabel2.setBounds(190, 20, 110, 100);

        jButton1.setBackground(new java.awt.Color(49, 51, 75));
        jButton1.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-cast-30.png"))); // NOI18N
        jButton1.setText("   patients      ");
        jButton1.setBorder(null);
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setOpaque(true);
        jButton1.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                jButton1MouseWheelMoved(evt);
            }
        });
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton1MouseExited(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);
        jButton1.setBounds(-60, 190, 360, 60);

        jButton4.setBackground(new java.awt.Color(49, 51, 75));
        jButton4.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-appointment-30.png"))); // NOI18N
        jButton4.setText("   Rendez-vous");
        jButton4.setBorder(null);
        jButton4.setBorderPainted(false);
        jButton4.setContentAreaFilled(false);
        jButton4.setOpaque(true);
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton4MouseExited(evt);
            }
        });
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton4);
        jButton4.setBounds(-50, 250, 360, 60);

        jButton6.setBackground(new java.awt.Color(49, 51, 75));
        jButton6.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-logout-rounded-down-30.png"))); // NOI18N
        jButton6.setText("  Se déconnecter ");
        jButton6.setBorder(null);
        jButton6.setBorderPainted(false);
        jButton6.setContentAreaFilled(false);
        jButton6.setOpaque(true);
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton6MouseExited(evt);
            }
        });
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton6);
        jButton6.setBounds(-30, 720, 350, 60);

        jButton8.setBackground(new java.awt.Color(49, 51, 75));
        jButton8.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-lock-30.png"))); // NOI18N
        jButton8.setText("   Change Password");
        jButton8.setBorder(null);
        jButton8.setBorderPainted(false);
        jButton8.setContentAreaFilled(false);
        jButton8.setOpaque(true);
        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton8MouseExited(evt);
            }
        });
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton8);
        jButton8.setBounds(0, 370, 300, 60);

        jButton9.setBackground(new java.awt.Color(49, 51, 75));
        jButton9.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-user-30 (3).png"))); // NOI18N
        jButton9.setText("   Change username");
        jButton9.setBorder(null);
        jButton9.setBorderPainted(false);
        jButton9.setContentAreaFilled(false);
        jButton9.setOpaque(true);
        jButton9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton9MouseExited(evt);
            }
        });
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton9);
        jButton9.setBounds(0, 310, 300, 60);

        jLabel7.setFont(new java.awt.Font("Times New Roman", 3, 28)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Cabinet dentaire");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(10, 70, 220, 30);
        jPanel2.add(jSeparator1);
        jSeparator1.setBounds(70, 140, 150, 10);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 290, 780);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(null);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel6.setText("Créons des beaux sourires");
        jPanel3.add(jLabel6);
        jLabel6.setBounds(290, 10, 300, 30);

        jLabel11.setBackground(new java.awt.Color(0, 92, 131));
        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 51, 51));
        jLabel11.setText("X");
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel11MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel11MouseExited(evt);
            }
        });
        jPanel3.add(jLabel11);
        jLabel11.setBounds(1230, 0, 20, 50);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-smiling-mouth-20.png"))); // NOI18N
        jPanel3.add(jLabel1);
        jLabel1.setBounds(560, 10, 30, 30);

        jPanel1.add(jPanel3);
        jPanel3.setBounds(0, 0, 1250, 50);

        jPanel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel4MouseClicked(evt);
            }
        });
        jPanel4.setLayout(null);

        jSeparator2.setForeground(new java.awt.Color(204, 204, 204));
        jPanel4.add(jSeparator2);
        jSeparator2.setBounds(50, 180, 131, 10);

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-patient-100.png"))); // NOI18N
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });
        jPanel4.add(jLabel14);
        jLabel14.setBounds(60, 30, 100, 100);

        jLabel16.setFont(new java.awt.Font("Times New Roman", 2, 14)); // NOI18N
        jLabel16.setText("No des patients");
        jPanel4.add(jLabel16);
        jLabel16.setBounds(70, 150, 90, 20);

        noP.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        noP.setForeground(new java.awt.Color(0, 92, 131));
        noP.setText("      ");
        noP.setToolTipText("");
        jPanel4.add(noP);
        noP.setBounds(100, 180, 80, 30);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/cadre.png"))); // NOI18N
        jPanel4.add(jLabel3);
        jLabel3.setBounds(0, 0, 230, 260);

        jPanel1.add(jPanel4);
        jPanel4.setBounds(420, 180, 230, 260);

        jPanel7.setLayout(null);

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-calendar-100.png"))); // NOI18N
        jPanel7.add(jLabel18);
        jLabel18.setBounds(60, 20, 100, 139);

        jSeparator3.setForeground(new java.awt.Color(204, 204, 204));
        jPanel7.add(jSeparator3);
        jSeparator3.setBounds(50, 190, 131, 10);

        noAP.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        noAP.setForeground(new java.awt.Color(0, 92, 131));
        noAP.setText("       ");
        jPanel7.add(noAP);
        noAP.setBounds(100, 190, 90, 20);

        jLabel19.setFont(new java.awt.Font("Times New Roman", 2, 14)); // NOI18N
        jLabel19.setText("No des rendez-vous");
        jPanel7.add(jLabel19);
        jLabel19.setBounds(60, 160, 131, 17);

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/cadre.png"))); // NOI18N
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });
        jPanel7.add(jLabel8);
        jLabel8.setBounds(0, 0, 230, 260);

        jPanel1.add(jPanel7);
        jPanel7.setBounds(970, 180, 230, 260);

        jPanel16.setBackground(new java.awt.Color(0, 92, 131));
        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel34.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("All rights Reserved");
        jPanel16.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 230, 260, 40));

        jLabel35.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-copyright-26.png"))); // NOI18N
        jPanel16.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 0, 100, 30));

        jLabel36.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("Tous les droits sont réservés");
        jPanel16.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 0, 260, 30));

        jLabel37.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("Copyright");
        jPanel16.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 0, 100, 30));

        jPanel1.add(jPanel16);
        jPanel16.setBounds(290, 750, 960, 40);

        jPanel6.setBackground(new java.awt.Color(0, 92, 131));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        welcome.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        welcome.setForeground(new java.awt.Color(255, 255, 255));
        jPanel6.add(welcome, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 210, 40));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("*Secrétaire*");
        jPanel6.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 192, 29));
        jPanel6.add(sec, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 10, 150, 40));

        jPanel1.add(jPanel6);
        jPanel6.setBounds(290, 50, 960, 90);

        jPanel9.setLayout(null);

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/IMG_P/icons8-calendar-100.png"))); // NOI18N
        jLabel20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel20MouseClicked(evt);
            }
        });
        jPanel9.add(jLabel20);
        jLabel20.setBounds(60, 20, 100, 139);

        jSeparator6.setForeground(new java.awt.Color(204, 204, 204));
        jPanel9.add(jSeparator6);
        jSeparator6.setBounds(50, 190, 131, 10);

        noAP1.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        noAP1.setForeground(new java.awt.Color(0, 92, 131));
        noAP1.setText("       ");
        jPanel9.add(noAP1);
        noAP1.setBounds(100, 190, 90, 20);

        jLabel25.setFont(new java.awt.Font("Times New Roman", 2, 14)); // NOI18N
        jLabel25.setText("Les rendez-vous d'aujourd'hui");
        jPanel9.add(jLabel25);
        jLabel25.setBounds(30, 160, 180, 17);

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cabinetdentaire/cadre.png"))); // NOI18N
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });
        jPanel9.add(jLabel9);
        jLabel9.setBounds(0, 0, 230, 260);

        jPanel1.add(jPanel9);
        jPanel9.setBounds(700, 180, 230, 260);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1247, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 783, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        setSize(new java.awt.Dimension(1247, 783));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jPanel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel4MouseClicked
        setVisible(false);
        new Patients1().setVisible(true);
    }//GEN-LAST:event_jPanel4MouseClicked

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
        setVisible(false);
        new Patients1().setVisible(true);
    }//GEN-LAST:event_jLabel14MouseClicked

    private void jLabel11MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseExited
        Color c = jLabel11.getBackground();
        jLabel11.setBackground(jLabel11.getForeground());
        jLabel11.setForeground(c);
    }//GEN-LAST:event_jLabel11MouseExited

    private void jLabel11MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseEntered
        Color c = jLabel11.getBackground(); // When the mouse moves over a label, the background color changed.
        jLabel11.setBackground(jLabel11.getForeground());
        jLabel11.setForeground(c);
    }//GEN-LAST:event_jLabel11MouseEntered

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        new userChanging().setVisible(true);
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseExited
        Color c = jButton9.getBackground();
        jButton9.setBackground(jButton9.getForeground());
        jButton9.setForeground(c);
    }//GEN-LAST:event_jButton9MouseExited

    private void jButton9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseEntered
        Color c = jButton9.getBackground();
        jButton9.setBackground(jButton9.getForeground());
        jButton9.setForeground(c);
    }//GEN-LAST:event_jButton9MouseEntered

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        new passChanging().setVisible(true);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseExited
        Color c = jButton8.getBackground();
        jButton8.setBackground(jButton8.getForeground());
        jButton8.setForeground(c);
    }//GEN-LAST:event_jButton8MouseExited

    private void jButton8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseEntered
        Color c = jButton8.getBackground();
        jButton8.setBackground(jButton8.getForeground());
        jButton8.setForeground(c);
    }//GEN-LAST:event_jButton8MouseEntered

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        this.dispose();
        new authentification().setVisible(true);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseExited
        Color c = jButton6.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton6.setBackground(jButton6.getForeground());
        jButton6.setForeground(c);
    }//GEN-LAST:event_jButton6MouseExited

    private void jButton6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseEntered
        Color c = jButton6.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton6.setBackground(jButton6.getForeground());
        jButton6.setForeground(c);
    }//GEN-LAST:event_jButton6MouseEntered

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        setVisible(false);
        new appointment().setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseExited
        Color c = jButton4.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton4.setBackground(jButton4.getForeground());
        jButton4.setForeground(c);
    }//GEN-LAST:event_jButton4MouseExited

    private void jButton4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseEntered
        Color c = jButton4.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton4.setBackground(jButton4.getForeground());
        jButton4.setForeground(c);
    }//GEN-LAST:event_jButton4MouseEntered

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        setVisible(false);
        new Patients1().setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseExited
        //if(!this.contains(evt.getPoint())) {
            //    jButton1.setBackground(Color.RED);
            //    }
        //else { jButton1.setBackground(Color.gray);
            //}

        Color c = jButton1.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton1.setBackground(jButton1.getForeground());
        jButton1.setForeground(c);
    }//GEN-LAST:event_jButton1MouseExited

    private void jButton1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseEntered
        Color c = jButton1.getBackground(); // When the mouse moves over a label, the background color changed.
        jButton1.setBackground(jButton1.getForeground());
        jButton1.setForeground(c);
    }//GEN-LAST:event_jButton1MouseEntered

    private void jButton1MouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_jButton1MouseWheelMoved

    }//GEN-LAST:event_jButton1MouseWheelMoved

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
  setVisible(false);
        new appointment().setVisible(true);
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
 setVisible(false);
        new t_appointments().setVisible(true);
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel20MouseClicked
setVisible(false);
        new t_appointments().setVisible(true);
    }//GEN-LAST:event_jLabel20MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Acceuil.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Acceuil.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Acceuil.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Acceuil.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Acceuil().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JLabel noAP;
    private javax.swing.JLabel noAP1;
    private javax.swing.JLabel noP;
    public static final javax.swing.JLabel sec = new javax.swing.JLabel();
    public static final javax.swing.JLabel welcome = new javax.swing.JLabel();
    // End of variables declaration//GEN-END:variables
}
