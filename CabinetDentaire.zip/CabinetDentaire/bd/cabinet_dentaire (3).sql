-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 28, 2022 at 10:38 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cabinet_dentaire`
--

-- --------------------------------------------------------

--
-- Table structure for table `consultation`
--

DROP TABLE IF EXISTS `consultation`;
CREATE TABLE IF NOT EXISTS `consultation` (
  `idC` int(11) NOT NULL AUTO_INCREMENT,
  `idp` varchar(50) NOT NULL,
  `medicines` varchar(50) NOT NULL,
  `nom_dentalp` varchar(50) NOT NULL,
  `cost_t` double NOT NULL,
  `cost_r` double NOT NULL,
  `descr` varchar(130) NOT NULL,
  PRIMARY KEY (`idC`),
  KEY `idp` (`idp`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `dentalp`
--

DROP TABLE IF EXISTS `dentalp`;
CREATE TABLE IF NOT EXISTS `dentalp` (
  `idd` int(50) NOT NULL AUTO_INCREMENT,
  `nom_dentalp` varchar(50) NOT NULL,
  PRIMARY KEY (`idd`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dentalp`
--

INSERT INTO `dentalp` (`idd`, `nom_dentalp`) VALUES
(11, 'Teeth Cleanings'),
(12, 'Teeth Whitening'),
(13, 'Fillings'),
(16, 'Crowns');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `id` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `type`) VALUES
('1', 'medecin', 'medecin', 'Medecin'),
('2', 'Imane', 'imane', 'Secretaire'),
('3', 'admin', 'admin', 'Administrateur');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
CREATE TABLE IF NOT EXISTS `patients` (
  `code` varchar(50) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `dateN` varchar(50) NOT NULL,
  `tel` varchar(50) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `adresse` varchar(50) NOT NULL,
  `allergie` varchar(50) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`code`, `nom`, `dateN`, `tel`, `sex`, `adresse`, `allergie`) VALUES
('4', 'ZEYNA SNO', '2022-08-08', '0654356724', 'Women', 'BD EL AMAL, CASABLANCA', 'SANS'),
('44', 'lamiaa chaf', '2006-08-10', '0654356724', 'Women', 'BD EL AMAL, CASABLANCA', 'SANS'),
('7', 'HICHAM ELO', '1996-08-09', '0654356724', 'Women', 'BD EL AMAL, CASABLANCA', 'SANS'),
('89', 'SALKK XKQ', '1996-10-03', '0654356724', 'Women', 'BD EL AMAL, CASABLANCA', 'SANS'),
('9', 'HIBA chaf', '1996-10-15', '0654356724', 'Women', 'BD EL AMAL, CASABLANCA', 'SANS');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

DROP TABLE IF EXISTS `prescription`;
CREATE TABLE IF NOT EXISTS `prescription` (
  `idP` int(50) NOT NULL AUTO_INCREMENT,
  `patientN` varchar(50) NOT NULL,
  `quantity` int(50) NOT NULL,
  `medicines` varchar(50) NOT NULL,
  `cost` double NOT NULL,
  PRIMARY KEY (`idP`),
  KEY `patientN` (`patientN`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`idP`, `patientN`, `quantity`, `medicines`, `cost`) VALUES
(13, '7', 3, 'JKH', 512),
(14, '9', 1, 'JKH', 653),
(17, '7', 3, 'JKH', 512),
(18, '7', 3, 'JKH', 512),
(19, '7', 3, 'JKH', 512),
(20, '7', 3, 'JKH', 512),
(21, '7', 3, 'JKH', 512);

-- --------------------------------------------------------

--
-- Table structure for table `ren`
--

DROP TABLE IF EXISTS `ren`;
CREATE TABLE IF NOT EXISTS `ren` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `dateR` varchar(50) NOT NULL,
  `heure` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `nom` (`nom`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ren`
--

INSERT INTO `ren` (`id`, `nom`, `dateR`, `heure`, `status`) VALUES
(46, '7', '2022-09-22', '12H43min', 'Present'),
(47, '44', '2022-10-18', '8H', 'Present'),
(48, '7', '2022-10-17', '10H', 'Present'),
(49, '4', '2022-10-22', '8H', 'Present'),
(50, '4', '2022-10-23', '8H', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

DROP TABLE IF EXISTS `treatment`;
CREATE TABLE IF NOT EXISTS `treatment` (
  `idT` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `cost` double NOT NULL,
  `medicines` varchar(50) NOT NULL,
  PRIMARY KEY (`idT`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `treatment`
--

INSERT INTO `treatment` (`idT`, `name`, `cost`, `medicines`) VALUES
(13, 'teeth whitenning', 120, 'SIGNAL'),
(14, 'TEETH WHITHENING', 321, 'FLAGYL');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `consultation`
--
ALTER TABLE `consultation`
  ADD CONSTRAINT `consultation_ibfk_1` FOREIGN KEY (`idp`) REFERENCES `patients` (`code`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `prescription`
--
ALTER TABLE `prescription`
  ADD CONSTRAINT `prescription_ibfk_1` FOREIGN KEY (`patientN`) REFERENCES `patients` (`code`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ren`
--
ALTER TABLE `ren`
  ADD CONSTRAINT `ren_ibfk_1` FOREIGN KEY (`nom`) REFERENCES `patients` (`code`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
